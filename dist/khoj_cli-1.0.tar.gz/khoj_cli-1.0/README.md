![image](https://github.com/Ajinkgupta/khoj-cli/assets/76146259/e1da9732-ec00-4e8d-b5b3-af600ccaf386)
